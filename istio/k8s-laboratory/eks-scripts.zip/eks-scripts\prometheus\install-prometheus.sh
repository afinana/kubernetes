helm install stable/prometheus --name prometheus -f values.yaml
