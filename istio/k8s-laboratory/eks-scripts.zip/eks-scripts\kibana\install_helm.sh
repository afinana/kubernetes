helm install stable/elasticsearch --name elastic-search
helm install stable/kibana --name kibana -f values.yaml
